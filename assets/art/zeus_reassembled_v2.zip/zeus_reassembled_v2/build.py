from pathlib import Path
from PIL import Image, ImageDraw
import numpy as np
import json, zipfile
root=Path(__file__).parent
src=Image.open('references/zeus_idle_01.png').convert('RGBA')
a=np.array(src); h,w=a.shape[:2]
# Visible-region partition only. No resizing, recoloring, new anatomy or hidden-joint inference.
regions=[
 ('staff_upper',[(443,240),(623,240),(623,511),(508,525),(476,502),(454,462),(454,400)]),
 ('head_visible',[(231,312),(411,306),(429,397),(410,438),(370,463),(302,453),(277,427),(251,420)]),
 ('front_hand_sleeve_visible',[(187,492),(215,477),(279,492),(289,535),(263,584),(260,619),(219,652),(176,667),(154,627),(137,605),(128,565),(151,544),(178,538)]),
 ('left_hair_visible',[(32,357),(161,354),(232,385),(251,420),(277,427),(275,470),(221,486),(187,492),(178,538),(151,544),(128,565),(137,605),(154,627),(176,667),(141,711),(55,695),(30,601)]),
 ('left_cloth_visible',[(31,700),(141,711),(176,667),(219,652),(260,619),(291,656),(296,747),(267,825),(249,904),(238,1000),(268,1076),(271,1140),(119,1152),(31,991)]),
 ('right_cloth_visible',[(476,729),(560,713),(623,758),(623,1153),(490,1146),(469,1096),(489,1036),(507,978),(500,915),(471,855),(458,789)])
]
labels=np.zeros((h,w),dtype=np.uint8)
for i,(name,poly) in enumerate(regions,1):
 mask=Image.new('L',(w,h));ImageDraw.Draw(mask).polygon(poly,fill=255)
 labels[(np.array(mask)>0)&(labels==0)]=i
entries=[]; compos=Image.new('RGBA',(w,h))
allnames=['body_remaining_visible']+[x[0] for x in regions]
scene=['[gd_scene load_steps=8 format=3]','']
for i,name in enumerate(allnames):
 pix=a.copy();pix[labels!=i]=0;pix[pix[:,:,3]==0]=0
 part=Image.fromarray(pix);part.save(root/'parts'/f'{name}.png')
 compos=Image.alpha_composite(compos,part)
 entries.append({'name':name,'file':f'parts/{name}.png','canvas':[w,h],'top_left':[0,0],'scale':[1,1],'visible_bbox':part.getbbox(),'occluded_pixels_reconstructed':False})
 scene.append(f'[ext_resource type="Texture2D" path="res://zeus_reassembled_v2/parts/{name}.png" id="{i+1}"]')
scene+=['','[node name="ZeusReassembled" type="Node2D"]','texture_filter = 1']
for i,name in enumerate(allnames):
 scene+=['',f'[node name="{name}" type="Sprite2D" parent="."]',f'texture = ExtResource("{i+1}")','centered = false']
(root/'zeus_reassembled.tscn').write_text('\n'.join(scene)+'\n')
compos.save(root/'zeus_reassembled.png')
expected=a.copy();expected[expected[:,:,3]==0]=0
out=np.array(compos)
assert np.array_equal(out,expected), 'Reassembly differs from original visible pixels'
# Each sheet cell is a layer, NOT an animation frame.
sheet=Image.new('RGBA',(w*4,h*2))
for i,e in enumerate(entries):sheet.paste(Image.open(root/e['file']),((i%4)*w,(i//4)*h))
sheet.save(root/'visible_parts_sheet.png')
(root/'manifest.json').write_text(json.dumps({'status':'static_visible_region_partition_not_complete_live2d_model','canvas':[w,h],'cell_size':[w,h],'sheet_size':[w*4,h*2],'sheet_columns':4,'sheet_cell_order':allnames,'assembly_origin':[0,0],'verified_visible_rgba_matches_source':True,'different_pixels':0,'source':'zeus_idle_01.png','layers':entries},ensure_ascii=False,indent=2))
(root/'README.txt').write_text('제우스 재조립 v2\n\n원본 768×1280 투명 PNG의 보이는 픽셀을 7개 영역으로 분리하고 동일 좌표에 재조립했습니다. 크기·얼굴·체형·자세 변경 없음. 투명 픽셀 RGB를 0으로 통일한 뒤 RGBA 비교: 다른 픽셀 0개. 원본의 반투명 가장자리도 그대로 보존했습니다.\n\nzeus_reassembled.png: 실제 분리 PNG를 합성한 결과\nparts/: 모든 영역 동일 768×1280, 좌상단 (0,0), 배율 1\nvisible_parts_sheet.png: 4열×2행 영역 시트. 애니메이션 프레임 시트가 아닙니다.\nmanifest.json: 영역 순서·캔버스·좌표\nzeus_reassembled.tscn: Godot 4 정적 조립 장면. 폴더를 res://zeus_reassembled_v2/에 넣으세요. 엔진에서 실행 검증하지 않았습니다.\n\n이 파일은 정적 외형 복구와 보이는 영역 분할본입니다. 관절용 겹침, 머리카락/팔 뒤 가려진 피부와 옷, 완전한 무기, 눈·입 분리, 변형 메시·리깅·애니메이션은 포함하지 않습니다. 팔 회전·고개 회전·큰 머리카락 동작 시 빈틈이 드러날 수 있습니다. 완성 Live2D 모델로 사용하지 마세요. 큰 동작 전에 가림부 보완과 파츠 경계 정리가 필요합니다.\n')
with zipfile.ZipFile(root.parent/'zeus_reassembled_v2.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in root.rglob('*'):
  if p.is_file():z.write(p,Path(root.name)/p.relative_to(root))
print('Verified: 0 different visible RGBA pixels; 7 fixed-size layers. ZIP created.')
